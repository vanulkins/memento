(function () {
  if (window.__MEMENTO_BRIDGE_READY__) return;
  window.__MEMENTO_BRIDGE_READY__ = true;

  var seq = 0;
  var callbacks = {};
  var listeners = {};
  var listenerById = {};
  // Native processing may resume before React has mounted its listeners. Keep the
  // latest event of each kind so terminal import/summary events are not lost.
  var queuedEvents = {};

  function nextId(prefix) { return (prefix || 'L') + (++seq); }

  function register(fn) {
    var id = String(++seq);
    callbacks[id] = fn;
    return id;
  }

  function unregister(id) {
    if (id != null) delete callbacks[id];
  }

  window.__mementoEmit = function (payload) {
    if (!payload) return;
    var fn = callbacks[payload.callbackId];
    if (!fn) return;
    try { fn(payload.content); } catch (e) { console.error('[bridge] callback failed', e); }
  };

  window.__mementoFire = function (event, payload) {
    var ids = listeners[event] || [];
    if (!ids.length) {
      queuedEvents[event] = payload;
      return;
    }
    for (var i = 0; i < ids.length; i++) {
      var lid = ids[i];
      var meta = listenerById[lid];
      if (!meta) continue;
      var handler = callbacks[meta.handlerId];
      if (!handler) continue;
      try { handler({ event: event, id: lid, payload: payload }); }
      catch (e) { console.error('[bridge] listener failed for ' + event, e); }
    }
  };

  function post(cmd, args, callbackId) {
    if (window.MementoBridge && typeof window.MementoBridge.post === 'function') {
      window.MementoBridge.post(JSON.stringify({ cmd: cmd, args: args || {}, callbackId: callbackId }));
      return true;
    }
    return false;
  }

  function invoke(cmd, args) {
    return new Promise(function (resolve, reject) {
      var callbackId = register(function (content) {
        unregister(callbackId);
        if (content && typeof content === 'object' && content.__mementoError !== undefined) {
          var message = String(content.__mementoError);
          try {
            window.dispatchEvent(new CustomEvent('memento:ai-error', { detail: { cmd: cmd, message: message } }));
          } catch (e) { }
          reject(new Error(message));
        } else if (content && typeof content === 'object' && 'value' in content) {
          var value = content.value;
          var path = window.location && window.location.pathname ? window.location.pathname : '';
          if (cmd === 'api_get_summary') {
            var unavailable = !value || value.unavailable === true || value.data == null || value.status === 'idle';
            document.documentElement.setAttribute('data-memento-summary-unavailable', unavailable ? '1' : '0');
            try {
              window.dispatchEvent(new CustomEvent('memento:summary-state', {
                detail: { unavailable: unavailable }
              }));
            } catch (e) { }
          }
          resolve(value);
        } else {
          resolve(content);
        }
      });
      if (!post(cmd, args, callbackId)) {
        unregister(callbackId);
        reject(new Error('native bridge is not available'));
      }
    });
  }

  // ---- event plugin ----
  function addListener(event, handlerId) {
    var lid = nextId('L');
    listenerById[lid] = { event: event, handlerId: handlerId };
    if (!listeners[event]) listeners[event] = [];
    listeners[event].push(lid);
    if (Object.prototype.hasOwnProperty.call(queuedEvents, event)) {
      var queued = queuedEvents[event];
      delete queuedEvents[event];
      setTimeout(function () { window.__mementoFire(event, queued); }, 0);
    }
    return lid;
  }

  function removeListener(event, lid) {
    var arr = listeners[event];
    if (arr) {
      var idx = arr.indexOf(lid);
      if (idx >= 0) arr.splice(idx, 1);
    }
    var meta = listenerById[lid];
    if (meta) unregister(meta.handlerId);
    delete listenerById[lid];
  }

  window.__TAURI_EVENT_PLUGIN_INTERNALS__ = {
    unregisterListener: function (event, id) { removeListener(event, String(id)); }
  };

  function windowCommand(name) {
    var vw = window.innerWidth || 360;
    var vh = window.innerHeight || 640;
    var dpr = window.devicePixelRatio || 1;
    var monitor = {
      name: 'Mobile display',
      size: { width: Math.round(vw * dpr), height: Math.round(vh * dpr) },
      position: { x: 0, y: 0 },
      scaleFactor: dpr,
      workArea: {
        position: { x: 0, y: 0 },
        size: { width: Math.round(vw * dpr), height: Math.round(vh * dpr) }
      }
    };
    switch (name) {
      case 'inner_size':
      case 'outer_size':
        return { width: Math.round(vw * dpr), height: Math.round(vh * dpr) };
      case 'inner_position':
      case 'outer_position':
        return { x: 0, y: 0 };
      case 'scale_factor':
        return dpr;
      case 'current_monitor':
      case 'primary_monitor':
      case 'monitor_from_point':
        return monitor;
      case 'available_monitors':
        return [monitor];
      case 'theme':
        return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
      case 'title':
      case 'is_maximized':
      case 'is_minimized':
      case 'is_fullscreen':
      case 'is_focused':
      case 'is_decorated':
      case 'is_resizable':
      case 'is_visible':
        return false;
      default:
        return null;
    }
  }

  var internals = {
    invoke: function (cmd, args) {
      args = args || {};
      if (cmd === 'plugin:event|listen') {
        return Promise.resolve(addListener(args.event, String(args.handler)));
      }
      if (cmd === 'plugin:event|unlisten') {
        removeListener(args.event, String(args.eventId));
        return Promise.resolve(null);
      }
      if (cmd === 'plugin:event|emit' || cmd === 'plugin:event|emit_to') {
        setTimeout(function () { window.__mementoFire(args.event, args.payload); }, 0);
        return Promise.resolve(null);
      }
      if (cmd.indexOf('plugin:window|') === 0) {
        return Promise.resolve(windowCommand(cmd.slice('plugin:window|'.length)));
      }
      return invoke(cmd, args);
    },
    transformCallback: function (fn, once) {
      var id = register(function (payload) {
        try { fn(payload); } finally { if (once) unregister(id); }
      });
      return id;
    },
    unregisterCallback: unregister,
    convertFileSrc: function (path) {
      return 'https://memento.app/__file/?p=' + encodeURIComponent(path || '');
    },
    metadata: { currentWindow: { label: 'main' }, currentWebview: { label: 'main' } },
    version: '2.0.0'
  };

  window.__TAURI_INTERNALS__ = internals;
  window.isTauri = true;

  // Some screens only start polling when the global object is present.
  window.__TAURI__ = {
    invoke: function (cmd, args) { return internals.invoke(cmd, args); },
    transformCallback: internals.transformCallback,
    convertFileSrc: internals.convertFileSrc,
    core: { invoke: function (cmd, args) { return internals.invoke(cmd, args); } },
    event: {
      listen: function (event, handler) {
        var handlerId = register(handler);
        var lid = addListener(event, handlerId);
        return Promise.resolve(function () { removeListener(event, lid); });
      },
      once: function (event, handler) {
        var handlerId = register(function (payload) {
          removeListener(event, lid);
          handler(payload);
        });
        var lid = addListener(event, handlerId);
        return Promise.resolve(function () { removeListener(event, lid); });
      },
      emit: function (event, payload) {
        setTimeout(function () { window.__mementoFire(event, payload); }, 0);
        return Promise.resolve();
      }
    },
    app: {
      getVersion: function () { return Promise.resolve('1.0.0'); },
      getName: function () { return Promise.resolve('Memento'); }
    },
    window: {
      getCurrentWindow: function () {
        return {
          label: 'main',
          listen: function () { return Promise.resolve(function () {}); },
          onCloseRequested: function () { return Promise.resolve(function () {}); },
          isMaximized: function () { return Promise.resolve(false); },
          isFullscreen: function () { return Promise.resolve(false); },
          innerSize: function () {
            return Promise.resolve({ width: window.innerWidth, height: window.innerHeight });
          },
          scaleFactor: function () { return Promise.resolve(window.devicePixelRatio || 1); },
          theme: function () { return Promise.resolve('light'); }
        };
      }
    }
  };
})();
