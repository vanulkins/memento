(function () {
  var boot = document.getElementById('memento-boot');
  var statusEl = boot ? boot.querySelector('.memento-boot__status') : null;
  var errors = [];
  var hidden = false;

  function setStatus(text) {
    if (!statusEl) return;
    statusEl.textContent = text;
    statusEl.classList.add('memento-boot__status--error');
  }

  function reportError(message) {
    if (!message) return;
    if (errors.indexOf(message) >= 0) return;
    errors.push(message);
    if (errors.length > 4) errors.shift();
    setStatus('Не удалось загрузить приложение.\n\n' + errors.join('\n\n'));
  }

  window.addEventListener('error', function (event) {
    if (event && event.message) reportError(String(event.message));
  });

  window.addEventListener('unhandledrejection', function (event) {
    var reason = event && event.reason;
    if (reason) reportError(String(reason && reason.message ? reason.message : reason));
  });

  function hideBoot() {
    if (hidden || !boot) return;
    hidden = true;
    boot.classList.add('memento-boot--hidden');
    try {
      if (window.MementoBridge && window.MementoBridge.ready) window.MementoBridge.ready();
    } catch (e) {}
    window.setTimeout(function () {
      if (boot && boot.parentNode) boot.parentNode.removeChild(boot);
    }, 320);
  }

  function appIsVisible() {
    if (document.querySelector('[class*="gateCover"]')) return false;
    var root = document.getElementById('__next') || document.body;
    return root && root.children.length > 0 && document.body.innerText.trim().length > 0;
  }

  var started = Date.now();
  var timer = window.setInterval(function () {
    if (appIsVisible()) {
      window.clearInterval(timer);
      window.setTimeout(hideBoot, 120);
      return;
    }
    if (Date.now() - started > 25000 && !errors.length) {
      window.clearInterval(timer);
      reportError('Приложение не ответило за 25 секунд.');
    }
  }, 120);

  // Keep the layout above the on-screen keyboard.
  if (window.visualViewport) {
    var applyViewport = function () {
      var vv = window.visualViewport;
      document.documentElement.style.setProperty('--memento-viewport-height', vv.height + 'px');
      document.documentElement.style.setProperty('--memento-keyboard-inset', Math.max(0, window.innerHeight - vv.height - vv.offsetTop) + 'px');
    };
    window.visualViewport.addEventListener('resize', applyViewport);
    window.visualViewport.addEventListener('scroll', applyViewport);
    applyViewport();
  }

  // Long-press should not open the browser context menu on app chrome.
  document.addEventListener('contextmenu', function (event) {
    var target = event.target;
    if (!target) return;
    if (target.closest('input, textarea, [contenteditable="true"], .selectable-text')) return;
    event.preventDefault();
  });

  // External links leave the app instead of replacing the local shell.
  document.addEventListener('click', function (event) {
    var anchor = event.target && event.target.closest ? event.target.closest('a[href]') : null;
    if (!anchor) return;
    var href = anchor.getAttribute('href') || '';
    if (!/^https?:\/\//i.test(href)) return;
    if (href.indexOf('memento.app') >= 0) return;
    event.preventDefault();
    try {
      if (window.MementoBridge && window.MementoBridge.post) {
        window.MementoBridge.post(JSON.stringify({
          cmd: 'open_external_url',
          args: { url: href },
          callbackId: '__none'
        }));
      } else {
        window.open(href, '_blank');
      }
    } catch (e) {
      console.warn('[mobile] failed to open external url', e);
    }
  }, true);

  function syncDrawerState() {
    var popup = document.querySelector('.memento-drawer-popup');
    var open = !!popup;
    if (document.body) document.body.classList.toggle('memento-drawer-open', open);
    var sidebar = document.querySelector('[data-sidebar="sidebar"][data-mobile="true"]');
    if (document.body) document.body.classList.toggle('memento-sidebar-open', !!sidebar);
    if (popup && !drawerWasOpen) {
      var resetScroll = function () {
        var sc = popup.querySelector('[class*="overflow-y-auto"]');
        if (sc && sc.scrollTop > 0) sc.scrollTop = 0;
      };
      window.setTimeout(resetScroll, 60);
      window.setTimeout(resetScroll, 600);
    }
    drawerWasOpen = open;
  }

  var drawerWasOpen = false;
  var lastGesture = 0;
  ['touchstart', 'mousedown', 'keydown'].forEach(function (name) {
    document.addEventListener(name, function () { lastGesture = Date.now(); }, true);
  });
  document.addEventListener('focusin', function (event) {
    var el = event.target;
    if (!el || !/^(INPUT|TEXTAREA)$/.test(el.tagName)) return;
    if (Date.now() - lastGesture < 800) return;
    el.blur();
  }, true);

  // Chat messages are inserted optimistically. Close the Android keyboard immediately after
  // submit so the newly inserted user bubble and typing indicator are visible while AI works.
  function dismissChatKeyboard() {
    if (location.pathname.indexOf('chat') < 0 && location.pathname.indexOf('meeting-details') < 0) return;
    var active = document.activeElement;
    if (active && active.tagName === 'TEXTAREA') window.setTimeout(function () { active.blur(); }, 0);
  }
  document.addEventListener('keydown', function (event) {
    if (event.key === 'Enter' && !event.shiftKey && event.target && event.target.tagName === 'TEXTAREA') {
      dismissChatKeyboard();
    }
  }, true);
  document.addEventListener('submit', dismissChatKeyboard, true);

  if (window.MutationObserver && document.documentElement) {
    new MutationObserver(function () {
      syncDrawerState();
      syncRoute();
      syncTopBar();
      scanAiErrors();
      normalizeInlineErrors();
    }).observe(document.documentElement, { childList: true, subtree: true });
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', syncDrawerState);
  } else {
    syncDrawerState();
  }

  function buildMenuButton() {
    if (!window.matchMedia('(max-width: 767px)').matches) return;
    if (!document.body || document.getElementById('memento-menu')) return;
    var btn = document.createElement('button');
    btn.id = 'memento-menu';
    btn.type = 'button';
    btn.setAttribute('aria-label', 'Меню');
    btn.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h16"/></svg>';
    btn.addEventListener('click', function () {
      document.body.classList.toggle('memento-menu-open');
    });
    document.body.appendChild(btn);

    var backdrop = document.createElement('div');
    backdrop.id = 'memento-menu-backdrop';
    backdrop.addEventListener('click', function () {
      document.body.classList.remove('memento-menu-open');
    });
    document.body.appendChild(backdrop);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', buildMenuButton);
  } else {
    buildMenuButton();
  }
  window.addEventListener('resize', buildMenuButton);

  document.addEventListener('click', function (event) {
    var target = event.target;
    if (!target || !target.closest) return;
    if (!target.closest('[class*="memento-settings-sidebar"]')) return;
    if (!target.closest('a, button')) return;
    window.setTimeout(function () {
      if (document.body) document.body.classList.remove('memento-menu-open');
    }, 160);
  }, true);


  var topbar = null;
  var topbarTitle = null;
  var meetingMoreProxy = null;

  function ensureMeetingMoreProxy() {
    if (meetingMoreProxy || !document.body) return meetingMoreProxy;
    meetingMoreProxy = document.createElement('button');
    meetingMoreProxy.id = 'memento-meeting-more';
    meetingMoreProxy.type = 'button';
    meetingMoreProxy.setAttribute('aria-label', 'Ещё действия');
    meetingMoreProxy.setAttribute('title', 'Ещё действия');
    meetingMoreProxy.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="5" cy="12" r="1.8"></circle><circle cx="12" cy="12" r="1.8"></circle><circle cx="19" cy="12" r="1.8"></circle></svg>';
    meetingMoreProxy.addEventListener('click', function () {
      var original = document.querySelector('[aria-label="Ещё действия"]:not(#memento-meeting-more), [aria-label="More actions"]:not(#memento-meeting-more)');
      if (!original) return;
      // Radix opens this menu on pointerdown rather than on a synthetic click.
      original.dispatchEvent(new PointerEvent('pointerdown', {
        bubbles: true, cancelable: true, button: 0, buttons: 1,
        pointerId: 1, pointerType: 'touch', isPrimary: true
      }));
      original.dispatchEvent(new PointerEvent('pointerup', {
        bubbles: true, cancelable: true, button: 0, buttons: 0,
        pointerId: 1, pointerType: 'touch', isPrimary: true
      }));
    });
    document.body.appendChild(meetingMoreProxy);
    return meetingMoreProxy;
  }

  function pageTitle() {
    var p = location.pathname;
    var isHome = p === '/' || p === '' || p.indexOf('index') >= 0;
    // A route can be rendered as a drawer over the home screen, which leaves the home
    // title in the DOM. Resolve the title inside the active route first.
    var scopes = [];
    if (p.indexOf('meeting-details') >= 0) scopes = ['.meeting-page-surface', '.memento-drawer-popup'];
    else if (p.indexOf('chat') >= 0) scopes = ['.memento-drawer-popup', '.memento-drawer-content'];
    else if (p.indexOf('settings') >= 0) scopes = ['.settings-screen'];
    else if (p.indexOf('collections') >= 0 || p.indexOf('search') >= 0) scopes = ['.mm-page'];
    for (var i = 0; i < scopes.length; i++) {
      var scope = document.querySelector(scopes[i]);
      if (!scope) continue;
      var scopeRect = scope.getBoundingClientRect();
      if (scopeRect.width < 2 || scopeRect.height < 2) continue;
      var scoped = scope.querySelector('h1.memento-screen-title, h1.mm-page-title');
      if (scoped) {
        var scopedText = (scoped.textContent || '').trim();
        if (scopedText) return scopedText;
      }
    }
    var popup = document.querySelector('.memento-drawer-popup');
    if (popup) {
      var popupRect = popup.getBoundingClientRect();
      if (popupRect.width < 2 || popupRect.height < 2) popup = null;
    }
    var h = popup ? popup.querySelector('h1.memento-screen-title, h1.mm-page-title') : null;
    if (!h) {
      var all = Array.prototype.slice.call(document.querySelectorAll(
        'h1.memento-screen-title, h1.mm-page-title, button.memento-screen-title'
      ));
      var visible = all.filter(function (el) {
        var r = el.getBoundingClientRect();
        if (r.width < 2 || r.height < 2) return false;
        var cs = getComputedStyle(el);
        return cs.display !== 'none' && cs.visibility !== 'hidden';
      });
      visible.sort(function (a, b) {
        return a.getBoundingClientRect().top - b.getBoundingClientRect().top;
      });
      h = visible[0] || all[0] || null;
    }
    if (h) {
      var text = (h.textContent || '').trim();
      if (text) return text;
    }
    if (isHome) return 'Встречи';
    if (p.indexOf('settings') >= 0) return 'Настройки';
    if (p.indexOf('chat') >= 0) return 'База знаний';
    if (p.indexOf('collections') >= 0) return 'Коллекции';
    if (p.indexOf('search') >= 0) return 'Поиск по встречам';
    if (p.indexOf('recording') >= 0) return 'Новая встреча';
    if (p.indexOf('meeting-details') >= 0) return 'Встреча';
    return 'Встречи';
  }

  function buildTopBar() {
    if (!window.matchMedia('(max-width: 767px)').matches) return;
    if (!document.body) return;
    if (!topbar) {
      topbar = document.createElement('div');
      topbar.id = 'memento-topbar';
      topbarTitle = document.createElement('div');
      topbarTitle.id = 'memento-topbar-title';
      topbar.appendChild(topbarTitle);
      document.body.appendChild(topbar);
    }
  }

  function syncTopBar() {
    buildTopBar();
    if (!topbar) return;
    var text = pageTitle();
    if (topbarTitle.textContent !== text) topbarTitle.textContent = text;
    if (document.body) document.body.classList.toggle('memento-has-topbar', !!text);
    syncMeetingLayers();
  }

  function syncMeetingLayers() {
    var isMeeting = document.documentElement.getAttribute('data-route') === 'meeting';
    var proxy = ensureMeetingMoreProxy();
    if (proxy) proxy.style.display = isMeeting ? 'inline-flex' : 'none';
    if (!isMeeting) return;
    var more = document.querySelector('[aria-label="Ещё действия"], [aria-label="More actions"]');
    if (more) {
      more.style.display = 'inline-flex';
      more.style.visibility = 'visible';
      more.style.opacity = '1';
      more.style.position = 'fixed';
      more.style.top = 'calc(11px + var(--memento-safe-top))';
      more.style.right = 'calc(10px + var(--memento-safe-right))';
      more.style.left = 'auto';
      more.style.zIndex = '62';
      var parent = more.parentElement;
      if (parent) {
        parent.style.position = 'relative';
        parent.style.zIndex = '70';
      }
    }
    var type = document.querySelector('[aria-label="Тип встречи"], [aria-label="Meeting type"]');
    if (type) {
      type.style.display = 'inline-flex';
      type.style.visibility = 'visible';
      type.style.opacity = '1';
      type.style.minWidth = '0';
      type.style.width = 'max-content';
      type.style.maxWidth = 'calc(100% - 24px)';
      var wrap = type.closest('.mt-2');
      if (wrap) wrap.style.marginBottom = '12px';
    }
  }

  var noticeEl = null;
  var toastEl = null;
  var noticeTimer = 0;
  var lastNotice = '';
  var lastNoticeAt = 0;

  function ensureNoticeEls() {
    if (!document.body) return;
    if (!noticeEl) {
      noticeEl = document.createElement('div');
      noticeEl.id = 'memento-notice';
      document.body.appendChild(noticeEl);
    }
    if (!toastEl) {
      toastEl = document.createElement('div');
      toastEl.id = 'memento-toast';
      document.body.appendChild(toastEl);
    }
  }

  function hideNotice() {
    if (noticeEl) noticeEl.classList.remove('memento-notice--show');
    if (toastEl) toastEl.classList.remove('memento-notice--show');
  }

  function notify(message) {
    var text = String(message || '').replace(/\s+/g, ' ').trim();
    if (!text) return;
    if (text.length > 240) text = text.slice(0, 237) + '...';
    var now = Date.now();
    if (text === lastNotice && now - lastNoticeAt < 2500) return;
    lastNotice = text;
    lastNoticeAt = now;
    ensureNoticeEls();
    if (!noticeEl || !toastEl) return;
    noticeEl.textContent = text;
    toastEl.textContent = text;
    noticeEl.classList.add('memento-notice--show');
    toastEl.classList.add('memento-notice--show');
    window.clearTimeout(noticeTimer);
    noticeTimer = window.setTimeout(hideNotice, 5200);
  }

  function notifyTop(message) {
    var text = String(message || '').replace(/\s+/g, ' ').trim();
    if (!text) return;
    var now = Date.now();
    if (text === lastNotice && now - lastNoticeAt < 2500) return;
    lastNotice = text;
    lastNoticeAt = now;
    ensureNoticeEls();
    if (!noticeEl) return;
    if (toastEl) toastEl.classList.remove('memento-notice--show');
    noticeEl.textContent = text;
    noticeEl.classList.add('memento-notice--show');
    window.clearTimeout(noticeTimer);
    noticeTimer = window.setTimeout(hideNotice, 5200);
  }

  var analyticsRequested = false;
  var analyticsNoticeAt = 0;
  var lastRouteKey = location.pathname + location.search;

  function isVisible(el) {
    if (!el) return false;
    var rect = el.getBoundingClientRect();
    if (rect.width <= 2 || rect.height <= 2) return false;
    var style = window.getComputedStyle(el);
    return style.display !== 'none' && style.visibility !== 'hidden' && Number(style.opacity) !== 0;
  }

  function notifyAnalyticsOnce() {
    var now = Date.now();
    if (!analyticsRequested || now - analyticsNoticeAt < 15000) return;
    analyticsNoticeAt = now;
    notifyTop('Не удалось создать отчет');
  }

  document.addEventListener('click', function (event) {
    var target = event.target && event.target.closest ? event.target.closest('button, [role="button"], a') : null;
    if (target && /(аналитик|analytics|отч[её]т|report)/i.test(target.textContent || '')) analyticsRequested = true;
  }, true);

  var aiError = /(недоступ|not available|нейросет|искусственн|AI |модел|model|саммари|summary|аналитик|analytics|failed to generate|could not generate|не удалось (создать|сгенерировать|загрузить|получить))/i;
  var analyticsError = /(аналитик|отч[её]т|analytics|report)/i;
  var savedSummaryError = /(сохран[её]нн\S*\s+суммар|saved summary|create saved summary)/i;

  function cleanHomeCards() {
    if (routeName() !== 'home') return;
    var nodes = document.querySelectorAll('[class*="Cell_caption"], [class*="caption"]');
    for (var i = 0; i < nodes.length; i++) {
      if (/суммаризация недоступна/i.test(nodes[i].textContent || '')) nodes[i].style.display = 'none';
    }
  }

  function scanAnalyticsDialog() {
    var dialogs = document.querySelectorAll('[role="dialog"]');
    for (var d = 0; d < dialogs.length; d++) {
      var dialog = dialogs[d];
      if (!isVisible(dialog)) continue;
      var title = (dialog.textContent || '').replace(/\s+/g, ' ');
      if (!/(Report failed|Не удалось собрать отч[её]т|Не удалось создать отчет)/i.test(title)) continue;
      var messages = dialog.querySelectorAll('p, pre');
      for (var j = 0; j < messages.length; j++) {
        var node = messages[j];
        var raw = (node.textContent || '').trim();
        if (!raw) continue;
        if (/(Error|Exception|java\.|is not available|not available|failed|Traceback|__memento|at app\.)/i.test(raw) || raw.length > 180) {
          node.textContent = 'Не удалось создать отчет.';
          node.classList.remove('text-destructive', 'text-red-500');
        }
      }
      if (!dialog.getAttribute('data-memento-analytics-notified')) {
        dialog.setAttribute('data-memento-analytics-notified', '1');
        notifyAnalyticsOnce();
      }
    }
  }

  function scanAiErrors() {
    if (!document.body) return;
    cleanHomeCards();
    scanAnalyticsDialog();
    pruneRemovedSettings();
    var savedToasts = document.querySelectorAll('[data-sonner-toast]');
    for (var st = 0; st < savedToasts.length; st++) {
      var toastType = savedToasts[st].getAttribute('data-type') || '';
      if (toastType === 'error' || savedSummaryError.test(savedToasts[st].textContent || '')) savedToasts[st].remove();
    }
    var searchCards = document.querySelectorAll('#settings-search .settings-section');
    for (var sc = 0; sc < searchCards.length; sc++) {
      if (/(Search model|Модель поиска|Multilingual E5|FRIDA)/i.test(searchCards[sc].textContent || '')) {
        searchCards[sc].style.display = 'none';
      }
    }
    var nodes = document.querySelectorAll('[class*=text-destructive], [role=alert], .text-red-500, [class*=destructive], pre, code, [class*=font-mono], [class*=whitespace-pre]');
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      // Feedback diagnostics are intentionally rendered as a <pre> inside the
      // original dialog. They are user-visible content, not an application
      // error, and must never be consumed by this generic error scrubber.
      if (el.closest('#memento-notice, #memento-toast, [data-sonner-toast], [data-sonner-toaster], .settings-screen, [role="dialog"]')) continue;
      if (!isVisible(el)) continue;
      if (el.getAttribute('data-memento-notified')) continue;
      var text = (el.textContent || '').replace(/\s+/g, ' ').trim();
      if (!text) continue;
      if (text.length > 400 && !analyticsError.test(text)) continue;
      if (/суммаризация недоступна/i.test(text)) continue;
      if (savedSummaryError.test(text)) {
        el.setAttribute('data-memento-notified', '1');
        el.style.display = 'none';
        continue;
      }
      if (!aiError.test(text)) continue;
      el.setAttribute('data-memento-notified', '1');
      var hide = el;
      if (el.tagName !== 'P' && el.tagName !== 'SPAN') {
        var inner = el.querySelector('p, span');
        if (inner) hide = inner;
      }
      hide.style.display = 'none';
      if (analyticsError.test(text)) notifyAnalyticsOnce();
    }
  }

  function normalizeInlineErrors() {
    var alerts = document.querySelectorAll('[role="alert"].text-destructive');
    for (var i = 0; i < alerts.length; i++) {
      var alert = alerts[i];
      var value = (alert.textContent || '').trim();
      if (/failed to instantiate extractor|extractor/i.test(value)) {
        alert.textContent = 'Не удалось прочитать аудиофайл. Выберите неповреждённую запись.';
      } else if (/file not found|no such file/i.test(value)) {
        alert.textContent = 'Файл больше недоступен. Выберите его ещё раз.';
      } else if (/ORT_|invalid dimensions|error code|inputs\/outputs/i.test(value)) {
        alert.textContent = 'Не удалось обработать эту запись. Попробуйте другой аудиофайл.';
      }
      alert.classList.remove('text-destructive');
      alert.classList.add('text-muted-foreground', 'memento-inline-notice');
    }
  }

  var removedSettingsReset = false;
  function pruneRemovedSettings() {
    ['settings-search', 'settings-calendar'].forEach(function (id) {
      var group = document.getElementById(id);
      if (group) group.style.setProperty('display', 'none', 'important');
    });
    var sections = document.querySelectorAll('.settings-section, .settings-cell');
    for (var i = 0; i < sections.length; i++) {
      var text = (sections[i].textContent || '').replace(/\s+/g, ' ').trim();
      if (/Автозапись звонков|Automatic call recording|Открывать Telegram после саммари|Open Telegram after a summary is generated/i.test(text)) {
        sections[i].style.setProperty('display', 'none', 'important');
      }
    }
    var headings = document.querySelectorAll('h2, h3');
    for (var h = 0; h < headings.length; h++) {
      var heading = (headings[h].textContent || '').replace(/\s+/g, ' ').trim();
      if (!/^(Автозапись звонков|Automatic call recording|Открывать Telegram после саммари|Open Telegram after a summary is generated)$/i.test(heading)) continue;
      var card = headings[h].closest('.settings-section, .settings-cell');
      if (!card) card = headings[h].parentElement && headings[h].parentElement.parentElement;
      if (card) card.style.setProperty('display', 'none', 'important');
    }
    var navigation = document.querySelectorAll('[role="tab"], .settings-screen nav button, .settings-screen aside button');
    for (var j = 0; j < navigation.length; j++) {
      var label = (navigation[j].textContent || '').replace(/\s+/g, ' ').trim();
      if (/^(Поиск|Search|Календарь|Calendar)$/i.test(label)) {
        navigation[j].style.setProperty('display', 'none', 'important');
      }
    }
    if (!removedSettingsReset && window.__TAURI_INTERNALS__) {
      removedSettingsReset = true;
      window.__TAURI_INTERNALS__.invoke('set_app_setting', { key: 'telegram.auto_share', value: 'false' }).catch(function () {});
    }
  }

  function routeName() {
    var p = location.pathname;
    if (p.indexOf('meeting-details') >= 0) return 'meeting';
    if (p.indexOf('settings') >= 0) return 'settings';
    if (p.indexOf('chat') >= 0) return 'chat';
    if (p.indexOf('recording') >= 0) return 'recording';
    if (p.indexOf('collections') >= 0) return 'collections';
    if (p.indexOf('search') >= 0) return 'search';
    return 'home';
  }

  function syncRoute() {
    var name = routeName();
    var routeFromPath = name;
    var key = location.pathname + location.search;
    if (key !== lastRouteKey) {
      lastRouteKey = key;
      analyticsRequested = false;
    }
    var popup = document.querySelector('.memento-drawer-popup');
    // Only infer a drawer route while the URL is still the home route. Explicit
    // /chat and /recording pages can leave the previous meeting surface mounted
    // underneath; that background must not turn them back into a meeting screen.
    if (popup && routeFromPath === 'home') {
      var r = popup.getBoundingClientRect();
      if (r.width > 2 && r.height > 2) {
        if (popup.querySelector('.settings-screen')) name = 'settings';
        else if (popup.querySelector('.meeting-conversation')) name = 'meeting';
        else if (popup.querySelector('h1.memento-screen-title')) name = 'chat';
      }
    }
    if (routeFromPath === 'home' && name !== 'meeting') {
      var surface = document.querySelector('.meeting-page-surface');
      if (surface) {
        var sr = surface.getBoundingClientRect();
        if (sr.width > 2 && sr.height > 2) name = 'meeting';
      }
    }
    var root = document.documentElement;
    if (root.getAttribute('data-route') !== name) root.setAttribute('data-route', name);
  }

  var importReconcileBusy = false;
  var importReconcileAt = 0;
  function reconcileFinishedImport() {
    if (importReconcileBusy || Date.now() - importReconcileAt < 1500) return;
    if (location.pathname.indexOf('meeting-details') < 0 || !window.__TAURI_INTERNALS__) return;
    var text = document.body ? document.body.innerText : '';
    if (text.indexOf('Идёт импорт этой встречи') < 0 && text.indexOf('This meeting is being imported') < 0) return;
    var id = new URLSearchParams(location.search).get('id');
    if (!id) return;
    importReconcileBusy = true;
    importReconcileAt = Date.now();
    window.__TAURI_INTERNALS__.invoke('get_import_activity_command').then(function (activity) {
      if (activity && (activity.meeting_id === id || activity.meetingId === id)) return null;
      return window.__TAURI_INTERNALS__.invoke('api_get_meeting_transcripts', { meetingId: id });
    }).then(function (result) {
      if (!result) return;
      var rows = Array.isArray(result) ? result : result.transcripts;
      if (!Array.isArray(rows) || !rows.length) return;
      window.__mementoFire('import-complete', {
        run_id: 'reconciled', meeting_id: id, segments_count: rows.length
      });
    }).catch(function () {}).finally(function () {
      importReconcileBusy = false;
    });
  }

  syncRoute();
  syncTopBar();
  window.setInterval(function () {
    syncRoute();
    syncTopBar();
    scanAiErrors();
    normalizeInlineErrors();
    reconcileFinishedImport();
  }, 500);

  window.__mementoBack = function () {
    if (window.history.length > 1) {
      window.history.back();
      return true;
    }
    return false;
  };

  window.__mementoBootHide = hideBoot;
  window.__mementoBootError = reportError;})();
