"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [2105],
  {
    4462: function (e, t, o) {
      o.d(t, {
        i: function () {
          return u;
        },
        Z: function () {
          return p;
        },
      });
      var n = o(15791),
        a = o(52236),
        r = o(5061);
      class i {
        async getTranscriptConfig() {
          return (0, r.invoke)("api_get_transcript_config");
        }
        async getModelConfig() {
          return (0, r.invoke)("api_get_model_config");
        }
        async getRecordingPreferences() {
          return (0, r.invoke)("get_recording_preferences");
        }
        async getCustomOpenAIConfig() {
          return (0, r.invoke)("api_get_custom_openai_config");
        }
        async saveCustomOpenAIConfig(e) {
          return (0, r.invoke)("api_save_custom_openai_config", {
            endpoint: e.endpoint,
            apiKey: e.apiKey,
            model: e.model,
            maxTokens: e.maxTokens,
            temperature: e.temperature,
            topP: e.topP,
          });
        }
        async testCustomOpenAIConnection(e, t, o) {
          return (0, r.invoke)("api_test_custom_openai_connection", {
            endpoint: e,
            apiKey: t,
            model: o,
          });
        }
      }
      let l = new i();
      var c = o(17140),
        s = o(49257);
      let d = (0, a.createContext)(void 0);
      function u(e) {
        let { children: t } = e,
          [i, u] = (0, a.useState)({
            provider: "deepseek",
            model: "deepseek-v4-pro",
            whisperModel: "large-v3",
            ollamaEndpoint: null,
          }),
          [p, g] = (0, a.useState)({
            provider: "gigaam",
            model: "gigaam-v3-e2e-rnnt-fp32",
            apiKey: null,
          }),
          [f, m] = (0, a.useState)({
            claude: null,
            groq: null,
            openai: null,
            openrouter: null,
          }),
          [v, y] = (0, a.useState)([]),
          [C, _] = (0, a.useState)(""),
          [h, k] = (0, a.useState)({ micDevice: null, systemDevice: null }),
          [S, w] = (0, a.useState)(() =>
            "en" === localStorage.getItem("primaryLanguage") ? "en" : "ru",
          ),
          [I, E] = (0, a.useState)(() => {
            {
              let e = localStorage.getItem("showConfidenceIndicator");
              return null === e || "true" === e;
            }
          }),
          [b, x] = (0, a.useState)(() => (0, s.rv)()),
          [M, A] = (0, a.useState)(null),
          [F, O] = (0, a.useState)(null),
          [P, L] = (0, a.useState)(!1),
          R = (0, a.useRef)(!1),
          N = (0, a.useRef)(!1);
        ((0, a.useEffect)(() => {
          (async () => {
            try {
              let e = i.ollamaEndpoint || null,
                t = await (0, r.invoke)("get_ollama_models", { endpoint: e });
              (y(t), _(""));
            } catch (e) {
              (_(
                e instanceof Error ? e.message : "Failed to load Ollama models",
              ),
                console.error("Error loading models:", e));
            }
          })();
        }, [i.ollamaEndpoint]),
          (0, a.useEffect)(() => {
            (async () => {
              try {
                let e = await l.getTranscriptConfig();
                e &&
                  (console.log(
                    "[ConfigContext] Loaded saved transcript config:",
                    e,
                  ),
                  g({
                    provider: e.provider || "parakeet",
                    model: e.model || "parakeet-tdt-0.6b-v3-int8",
                    apiKey: e.apiKey || null,
                  }));
              } catch (e) {
                console.error(
                  "[ConfigContext] Failed to load transcript config:",
                  e,
                );
              }
            })();
          }, []),
          (0, a.useEffect)(() => {
            if (S) {
              try {
                localStorage.getItem("primaryLanguage") !== S &&
                  localStorage.setItem("primaryLanguage", S);
              } catch (e) {}
              (0, r.invoke)("set_language_preference", { language: S })
                .then(() => {
                  console.log(
                    "[ConfigContext] Synced language preference to Rust on startup:",
                    S,
                  );
                })
                .catch((e) => {
                  console.error(
                    "[ConfigContext] Failed to sync language preference to Rust on startup:",
                    e,
                  );
                });
            }
          }, []),
          (0, a.useEffect)(() => {
            (async () => {
              try {
                let e = await l.getModelConfig();
                if (e && e.provider) {
                  if ("custom-openai" === e.provider)
                    try {
                      let t = await l.getCustomOpenAIConfig();
                      if (t) {
                        console.log(
                          "[ConfigContext] Loading custom OpenAI config:",
                          { endpoint: t.endpoint, model: t.model },
                        );
                        let o = t.model || e.model || "";
                        if (
                          (u((n) => ({
                            ...n,
                            provider: e.provider,
                            model: o || n.model,
                            whisperModel: e.whisperModel || n.whisperModel,
                            customOpenAIEndpoint: t.endpoint,
                            customOpenAIModel: t.model,
                            customOpenAIApiKey: t.apiKey,
                            maxTokens: t.maxTokens,
                            temperature: t.temperature,
                            topP: t.topP,
                          })),
                          o)
                        ) {
                          let t = JSON.parse(
                            localStorage.getItem("providerModelMap") || "{}",
                          );
                          ((t[e.provider] = o),
                            localStorage.setItem(
                              "providerModelMap",
                              JSON.stringify(t),
                            ));
                        }
                        return;
                      }
                    } catch (e) {
                      console.error(
                        "[ConfigContext] Failed to fetch custom OpenAI config:",
                        e,
                      );
                    }
                  if (
                    (u((t) => ({
                      ...t,
                      provider: e.provider,
                      model: e.model || t.model,
                      whisperModel: e.whisperModel || t.whisperModel,
                      ollamaEndpoint: e.ollamaEndpoint,
                    })),
                    e.model)
                  ) {
                    let t = JSON.parse(
                      localStorage.getItem("providerModelMap") || "{}",
                    );
                    ((t[e.provider] = e.model),
                      localStorage.setItem(
                        "providerModelMap",
                        JSON.stringify(t),
                      ));
                  }
                }
              } catch (e) {
                console.error(
                  "Failed to fetch saved model config in ConfigContext:",
                  e,
                );
              }
            })();
          }, []),
          (0, a.useEffect)(() => {
            (async () => {
              try {
                let e = await Promise.all(
                  ["claude", "groq", "openai", "openrouter"].map((e) =>
                    (0, r.invoke)("api_get_api_key", { provider: e }).catch(
                      () => null,
                    ),
                  ),
                );
                (m({
                  claude: e[0],
                  groq: e[1],
                  openai: e[2],
                  openrouter: e[3],
                }),
                  console.log("[ConfigContext] Loaded provider API keys"));
              } catch (e) {
                console.error(
                  "[ConfigContext] Failed to load provider API keys:",
                  e,
                );
              }
            })();
          }, []),
          (0, a.useEffect)(() => {
            let e;
            return (
              (async () => {
                let { listen: e } = await Promise.resolve().then(
                  o.bind(o, 31648),
                );
                return await e("model-config-updated", (e) => {
                  (console.log(
                    "[ConfigContext] Received model-config-updated event:",
                    e.payload,
                  ),
                    u(e.payload),
                    e.payload.apiKey &&
                      "custom-openai" !== e.payload.provider &&
                      T(e.payload.provider, e.payload.apiKey));
                });
              })().then((t) => (e = t)),
              () => {
                null == e || e();
              }
            );
          }, []),
          (0, a.useEffect)(() => {
            (async () => {
              try {
                let e = await l.getRecordingPreferences();
                e &&
                  (e.preferred_mic_device || e.preferred_system_device) &&
                  (k({
                    micDevice: e.preferred_mic_device,
                    systemDevice: e.preferred_system_device,
                  }),
                  console.log("Loaded device preferences:", e));
              } catch (e) {
                console.log(
                  "No device preferences found or failed to load:",
                  e,
                );
              }
            })();
          }, []));
        let K = {
            ollama: v.map((e) => e.name),
            claude: ["claude-3-5-sonnet-latest"],
            groq: ["llama-3.3-70b-versatile"],
            openrouter: ["~anthropic/claude-sonnet-latest"],
            openai: ["gpt-4", "gpt-4-turbo", "gpt-3.5-turbo"],
            "builtin-ai": [],
            "custom-openai": [],
            gigachat: [
              "GigaChat-3-Ultra",
              "GigaChat-3.5-432B-A28B",
              "GigaChat-2-Max",
              "GigaChat",
            ],
            deepseek: ["deepseek-v4-pro", "deepseek-v4-flash"],
          },
          D = (0, a.useCallback)((e) => {
            (E(e),
              localStorage.setItem("showConfidenceIndicator", e.toString()),
              window.dispatchEvent(
                new CustomEvent("confidenceIndicatorChanged", { detail: e }),
              ));
          }, []),
          J = (0, a.useCallback)((e, t) => {
            x((o) => {
              let n = { ...o, [e]: t };
              return (
                (0, s.vo)(n),
                c.Z.track("beta_feature_toggled", {
                  feature: e,
                  enabled: t.toString(),
                }).catch((e) =>
                  console.error("Failed to track beta feature toggle:", e),
                ),
                n
              );
            });
          }, []),
          T = (0, a.useCallback)((e, t) => {
            m((o) => ({ ...o, [e]: t }));
          }, []),
          q = (0, a.useCallback)(async () => {
            if (!R.current && !N.current) {
              ((N.current = !0), L(!0));
              try {
                let e = null;
                try {
                  ((e = await (0, r.invoke)("get_notification_settings")),
                    A(e));
                } catch (e) {
                  (console.error(
                    "[ConfigContext] Failed to load notification settings:",
                    e,
                  ),
                    A(null));
                }
                let [t, o, n] = await Promise.all([
                  (0, r.invoke)("get_database_directory"),
                  (0, r.invoke)("whisper_get_models_directory"),
                  (0, r.invoke)("get_default_recordings_folder_path"),
                ]);
                (O({ database: t, models: o, recordings: n }),
                  (R.current = !0));
              } catch (e) {
                console.error("[ConfigContext] Failed to load preferences:", e);
              } finally {
                ((N.current = !1), L(!1));
              }
            }
          }, []),
          B = (0, a.useCallback)(async (e) => {
            try {
              (await (0, r.invoke)("set_notification_settings", {
                settings: e,
              }),
                A(e));
            } catch (e) {
              throw (
                console.error(
                  "[ConfigContext] Failed to update notification settings:",
                  e,
                ),
                e
              );
            }
          }, []),
          G = (0, a.useCallback)((e) => {
            (w(e),
              localStorage.setItem("primaryLanguage", e),
              (0, r.invoke)("set_language_preference", { language: e }).catch(
                (e) =>
                  console.error(
                    "Failed to sync language preference to Rust:",
                    e,
                  ),
              ));
          }, []),
          Z = (0, a.useMemo)(
            () => ({
              modelConfig: i,
              setModelConfig: u,
              isAutoSummary: !0,
              providerApiKeys: f,
              updateProviderApiKey: T,
              transcriptModelConfig: p,
              setTranscriptModelConfig: g,
              selectedDevices: h,
              setSelectedDevices: k,
              selectedLanguage: S,
              setSelectedLanguage: G,
              showConfidenceIndicator: I,
              toggleConfidenceIndicator: D,
              betaFeatures: b,
              toggleBetaFeature: J,
              models: v,
              modelOptions: K,
              error: C,
              notificationSettings: M,
              storageLocations: F,
              isLoadingPreferences: P,
              loadPreferences: q,
              updateNotificationSettings: B,
            }),
            [i, !0, f, T, p, h, S, G, I, D, b, J, v, K, C, M, F, P, q, B],
          );
        return (0, n.jsx)(d.Provider, { value: Z, children: t });
      }
      function p() {
        let e = (0, a.useContext)(d);
        if (void 0 === e)
          throw Error("useConfig must be used within a ConfigProvider");
        return e;
      }
    },
    48544: function (e, t, o) {
      o.d(t, {
        L: function () {
          return a;
        },
      });
      var n = o(52236);
      function a(e) {
        let { open: t, close: o, onEscapeKeyDown: a } = e,
          r = (0, n.useRef)(null);
        return (
          (0, n.useEffect)(() => {
            if (!t) return;
            let e = (e) => {
              if ("Escape" !== e.key || e.defaultPrevented) return;
              let t = r.current;
              if (!t) return;
              let n = e.target;
              n instanceof Node &&
                t.contains(n) &&
                (e.stopImmediatePropagation(),
                null == a || a(e),
                e.defaultPrevented || null == o || o());
            };
            return (
              document.addEventListener("keydown", e, !0),
              () => document.removeEventListener("keydown", e, !0)
            );
          }, [t, o, a]),
          r
        );
      }
    },
    49257: function (e, t, o) {
      o.d(t, {
        rv: function () {
          return r;
        },
        vo: function () {
          return i;
        },
      });
      let n = { importAndRetranscribe: !0, noisyAudioDenoising: !0 },
        a = ["importAndRetranscribe", "noisyAudioDenoising"];
      function r() {
        try {
          let e = localStorage.getItem("betaFeatures");
          if (e) {
            let t = JSON.parse(e),
              o = { ...n, ...t };
            return (
              a.forEach((e) => {
                o[e] = !0;
              }),
              o
            );
          }
        } catch (e) {
          console.error("[BetaFeatures] Failed to load from localStorage:", e);
        }
        return { ...n };
      }
      function i(e) {
        try {
          localStorage.setItem("betaFeatures", JSON.stringify(e));
        } catch (e) {
          console.error("[BetaFeatures] Failed to save to localStorage:", e);
        }
      }
    },
  },
]);
