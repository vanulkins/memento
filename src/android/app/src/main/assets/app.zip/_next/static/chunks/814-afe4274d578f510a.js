"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [814],
  {
    42843: function (e, s, t) {
      t.d(s, {
        n: function () {
          return u;
        },
      });
      var a = t(15791),
        i = t(52236),
        l = t(5061),
        n = t(27083),
        c = t(33112),
        o = t(61362),
        r = t(17140),
        d = t(9389);
      function u(e) {
        let { selectedDevices: s, onDeviceChange: t, disabled: u = !1 } = e,
          h = (0, d.NT)(),
          [_, g] = (0, i.useState)([]),
          [m, p] = (0, i.useState)(!0),
          [f, v] = (0, i.useState)(null),
          x = _.filter((e) => "Input" === e.device_type),
          j = _.filter((e) => "Output" === e.device_type),
          N = async () => {
            try {
              v(null);
              let e = await (0, l.invoke)("get_audio_devices");
              (g(e), console.log("Fetched audio devices:", e));
            } catch (e) {
              (console.error("Failed to fetch audio devices:", e),
                v(
                  h(
                    "Failed to load audio devices. Please check your system audio settings.",
                  ),
                ));
            } finally {
              p(!1);
            }
          };
        (0, i.useEffect)(() => {
          N();
        }, []);
        let y = (e) => {
          let s = e.toLowerCase(),
            t =
              s.includes("airpods") ||
              s.includes("bluetooth") ||
              s.includes("wireless") ||
              s.includes("wh-") ||
              s.includes("bt "),
            a = "wired";
          return (
            "default" === e
              ? (a = "default")
              : s.includes("airpods")
                ? (a = "airpods")
                : t && (a = "bluetooth"),
            { isBluetooth: t, category: a }
          );
        };
        return m
          ? (0, a.jsx)("div", {
              className: "p-4 space-y-4",
              children: (0, a.jsxs)("div", {
                className: "animate-pulse",
                children: [
                  (0, a.jsx)("div", {
                    className: "h-4 bg-muted rounded w-1/3 mb-4",
                  }),
                  (0, a.jsx)("div", {
                    className: "h-10 bg-muted rounded mb-3",
                  }),
                  (0, a.jsx)("div", { className: "h-10 bg-muted rounded" }),
                ],
              }),
            })
          : (0, a.jsxs)(a.Fragment, {
              children: [
                f &&
                  (0, a.jsx)("div", {
                    className:
                      "p-3 text-sm text-destructive bg-destructive/10 border border-destructive/40 rounded-md",
                    children: f,
                  }),
                (0, a.jsx)("section", {
                  className: "settings-section settings-cell",
                  children: (0, a.jsxs)("div", {
                    className: "settings-cell__row",
                    children: [
                      (0, a.jsx)("span", {
                        className: "settings-cell__avatar",
                        "aria-hidden": "true",
                        children: (0, a.jsx)(n.uc, { size: 20 }),
                      }),
                      (0, a.jsxs)("div", {
                        className: "settings-cell__text",
                        children: [
                          (0, a.jsx)(o._, {
                            htmlFor: "mic-selection",
                            className: "settings-cell__label",
                            children: h("Microphone"),
                          }),
                          (0, a.jsx)("p", {
                            className: "settings-cell__caption",
                            children:
                              0 === x.length
                                ? h("No microphone devices found")
                                : h("Voice input device"),
                          }),
                        ],
                      }),
                      (0, a.jsx)("div", {
                        className: "settings-cell__control",
                        children: (0, a.jsxs)(c.Ph, {
                          shape: "rounded",
                          value: s.micDevice || "default",
                          onValueChange: (e) => {
                            const i = "default" === e ? null : e;
                            t({ ...s, micDevice: i });
                            (0, l.invoke)("set_recording_preferences", {
                              preferences: { preferred_mic_device: i },
                            }).catch((e) =>
                              console.error(
                                "Failed to save microphone selection:",
                                e,
                              ),
                            );
                            let a = y(e);
                            r.Z.track("microphone_selected", {
                              device_category: a.category,
                              is_bluetooth: a.isBluetooth.toString(),
                              has_system_audio: (!!s.systemDevice).toString(),
                            }).catch((e) =>
                              console.error(
                                "Failed to track microphone selection:",
                                e,
                              ),
                            );
                          },
                          disabled: u,
                          children: [
                            (0, a.jsx)(c.i4, {
                              id: "mic-selection",
                              className:
                                "settings-cell__select settings-cell__device-select",
                              placeholder: h("Select Microphone"),
                            }),
                            (0, a.jsxs)(c.Bw, {
                              children: [
                                (0, a.jsx)(c.Ql, {
                                  index: 0,
                                  value: "default",
                                  children: h("Default Microphone"),
                                }),
                                x.map((e, s) =>
                                  (0, a.jsx)(
                                    c.Ql,
                                    {
                                      index: s + 1,
                                      value: ""
                                        .concat(e.name, " (")
                                        .concat(
                                          e.device_type.toLowerCase(),
                                          ")",
                                        ),
                                      children: e.name,
                                    },
                                    e.name,
                                  ),
                                ),
                              ],
                            }),
                          ],
                        }),
                      }),
                    ],
                  }),
                }),
                (0, a.jsx)("section", {
                  className: "settings-section settings-cell",
                  children: (0, a.jsxs)("div", {
                    className: "settings-cell__row",
                    children: [
                      (0, a.jsx)("span", {
                        className: "settings-cell__avatar",
                        "aria-hidden": "true",
                        children: (0, a.jsx)(n.bM, { size: 20 }),
                      }),
                      (0, a.jsxs)("div", {
                        className: "settings-cell__text",
                        children: [
                          (0, a.jsx)(o._, {
                            htmlFor: "system-selection",
                            className: "settings-cell__label",
                            children: h("System Audio"),
                          }),
                          (0, a.jsx)("p", {
                            className: "settings-cell__caption",
                            children:
                              0 === j.length
                                ? h("No system audio devices found")
                                : h("Computer and call audio"),
                          }),
                        ],
                      }),
                      (0, a.jsx)("div", {
                        className: "settings-cell__control",
                        children: (0, a.jsxs)(c.Ph, {
                          shape: "rounded",
                          value: s.systemDevice || "default",
                          onValueChange: (e) => {
                            const i = "default" === e ? null : e;
                            t({
                              ...s,
                              systemDevice: i,
                            });
                            (0, l.invoke)("set_recording_preferences", {
                              preferences: { preferred_system_device: i },
                            }).catch((e) =>
                              console.error(
                                "Failed to save system audio selection:",
                                e,
                              ),
                            );
                            let a = y(e);
                            r.Z.track("system_audio_selected", {
                              device_category: a.category,
                              is_bluetooth: a.isBluetooth.toString(),
                              has_microphone: (!!s.micDevice).toString(),
                            }).catch((e) =>
                              console.error(
                                "Failed to track system audio selection:",
                                e,
                              ),
                            );
                          },
                          disabled: u,
                          children: [
                            (0, a.jsx)(c.i4, {
                              id: "system-selection",
                              className:
                                "settings-cell__select settings-cell__device-select",
                              placeholder: h("Select System Audio"),
                            }),
                            (0, a.jsxs)(c.Bw, {
                              children: [
                                (0, a.jsx)(c.Ql, {
                                  index: 0,
                                  value: "default",
                                  children: h("Default System Audio"),
                                }),
                                j.map((e, s) =>
                                  (0, a.jsx)(
                                    c.Ql,
                                    {
                                      index: s + 1,
                                      value: ""
                                        .concat(e.name, " (")
                                        .concat(
                                          e.device_type.toLowerCase(),
                                          ")",
                                        ),
                                      children: e.name,
                                    },
                                    e.name,
                                  ),
                                ),
                              ],
                            }),
                          ],
                        }),
                      }),
                    ],
                  }),
                }),
              ],
            });
      }
    },
    43849: function (e, s, t) {
      t.d(s, {
        O: function () {
          return f;
        },
      });
      var a = t(15791),
        i = t(52236),
        l = t(6503),
        n = t(33112),
        c = t(67975),
        o = t(5061),
        r = t(17140),
        d = t(4462),
        u = t(52822),
        h = t(9389);
      let _ = "hide_from_dock",
        g = (0, c.h3)("call", "IconCall"),
        m = (0, c.h3)("dock_to_left", "IconDock"),
        p = (0, c.h3)("language", "IconLanguage");
      function f() {
        let [e, s] = (0, i.useState)(!1),
          {
            notificationSettings: t,
            isLoadingPreferences: f,
            loadPreferences: v,
            updateNotificationSettings: x,
          } = (0, d.Z)(),
          { t: j, lang: N, setLang: y } = (0, h.ZK)(),
          [w, k] = (0, i.useState)(null),
          [b, S] = (0, i.useState)(!0),
          [C, D] = (0, i.useState)(null),
          [F, E] = (0, i.useState)(null),
          [Z, L] = (0, i.useState)(!1),
          [M, P] = (0, i.useState)(!1),
          z =
            "undefined" != typeof navigator && /mac/i.test(navigator.userAgent),
          [A, Q] = (0, i.useState)(null),
          B = (0, i.useRef)(!1);
        if (
          ((0, i.useEffect)(() => {
            (v(), (B.current = !1));
          }, [v]),
          (0, i.useEffect)(() => {
            Promise.all([
              (0, o.invoke)("get_capture_retention_policy"),
              (0, o.invoke)("get_app_settings"),
              (0, o.invoke)("get_background_capture_status"),
            ])
              .then((e) => {
                let [s, t, a] = e;
                (E(s.local_only),
                  L("true" === t[u.r]),
                  P("true" === t[_]),
                  Q({ supported: a.supported, capturing: a.capturing }));
              })
              .catch((e) => {
                console.warn("Failed to load local learning policy:", e);
              });
          }, []),
          (0, i.useEffect)(() => {
            B.current ||
              (async () => {
                t
                  ? (await r.Z.track("preferences_viewed", {
                      notifications_enabled: t.notification_preferences
                        .show_recording_started
                        ? "true"
                        : "false",
                    }),
                    (B.current = !0))
                  : f ||
                    (await r.Z.track("preferences_viewed", {
                      notifications_enabled: "false",
                    }),
                    (B.current = !0));
              })();
          }, [t, f]),
          (0, i.useEffect)(() => {
            if (t) {
              let e =
                t.notification_preferences.show_recording_started &&
                t.notification_preferences.show_recording_stopped;
              (k(e), b && (D(e), S(!1)));
            } else !f && (k(!0), b && (D(!0), S(!1)));
          }, [t, f, b]),
          (0, i.useEffect)(() => {
            !b &&
              null !== w &&
              w !== C &&
              t &&
              (async () => {
                console.log("Updating notification settings to:", w);
                try {
                  let e = {
                    ...t,
                    notification_preferences: {
                      ...t.notification_preferences,
                      show_recording_started: w,
                      show_recording_stopped: w,
                    },
                  };
                  (console.log("Calling updateNotificationSettings with:", e),
                    await x(e),
                    D(w),
                    console.log(
                      "Successfully updated notification settings to:",
                      w,
                    ),
                    await r.Z.track("notification_settings_changed", {
                      notifications_enabled: w.toString(),
                    }));
                } catch (e) {
                  console.error("Failed to update notification settings:", e);
                }
              })();
          }, [w, t, b, C, x]),
          (f && !t) || (null === w && !f))
        )
          return (0, a.jsx)("div", {
            className: "max-w-2xl mx-auto p-6",
            children: j("Loading Preferences..."),
          });
        let I = null != w && w,
          V = t
            ? t.auto_meeting_detection && t.auto_listening
              ? "live"
              : "off"
            : null,
          O = async (a) => {
            if (t && !e && a !== V) {
              s(!0);
              try {
                (await x({
                  ...t,
                  auto_meeting_detection: "off" !== a,
                  auto_listening: "live" === a,
                  background_auto_recording: !1,
                }),
                  await r.Z.track("auto_capture_mode_changed", { mode: a }));
              } catch (e) {
                console.error(
                  "Failed to update what happens when a call is detected:",
                  e,
                );
              } finally {
                s(!1);
              }
            }
          },
          T = async (e) => {
            P(e);
            try {
              (await (0, o.invoke)("set_app_setting", {
                key: _,
                value: e ? "true" : "false",
              }),
                await (0, o.invoke)("set_hidden_from_dock", { hidden: e }));
            } catch (s) {
              (P(!e),
                (0, o.invoke)("set_app_setting", {
                  key: _,
                  value: e ? "false" : "true",
                }).catch(() => {}),
                console.error("Failed to change the Dock setting:", s));
            }
          },
          R = async (e) => {
            L(e);
            try {
              await (0, o.invoke)("set_app_setting", {
                key: u.r,
                value: e ? "true" : "false",
              });
            } catch (s) {
              (L(!e),
                console.error(
                  "Failed to save Telegram auto-share setting:",
                  s,
                ));
            }
          };
        return (0, a.jsxs)("div", {
          className: "space-y-6",
          children: [
            (0, a.jsx)("div", {
              className: "settings-section settings-cell",
              children: (0, a.jsxs)("div", {
                className: "settings-cell__row",
                children: [
                  (0, a.jsx)("span", {
                    className: "settings-cell__avatar",
                    "aria-hidden": "true",
                    children: (0, a.jsx)(p, { size: 20, weight: 400 }),
                  }),
                  (0, a.jsxs)("div", {
                    className: "settings-cell__text",
                    children: [
                      (0, a.jsx)("h3", {
                        className: "settings-cell__label",
                        children: j("Interface language"),
                      }),
                      (0, a.jsx)("p", {
                        className: "settings-cell__caption",
                        children: j("Language of menus and settings"),
                      }),
                    ],
                  }),
                  (0, a.jsx)("div", {
                    className: "settings-cell__control",
                    children: (0, a.jsxs)(n.Ph, {
                      shape: "rounded",
                      value: N,
                      onValueChange: (e) => y("en" === e ? "en" : "ru"),
                      children: [
                        (0, a.jsx)(n.i4, {
                          className:
                            "settings-cell__select settings-cell__device-select",
                        }),
                        (0, a.jsxs)(n.Bw, {
                          children: [
                            (0, a.jsx)(n.Ql, {
                              index: 0,
                              value: "ru",
                              children: "Русский",
                            }),
                            (0, a.jsx)(n.Ql, {
                              index: 1,
                              value: "en",
                              children: "English",
                            }),
                          ],
                        }),
                      ],
                    }),
                  }),
                ],
              }),
            }),
            (0, a.jsx)("div", {
              className: "settings-section settings-cell",
              children: (0, a.jsxs)("div", {
                className: "settings-cell__row",
                children: [
                  (0, a.jsx)("span", {
                    className: "settings-cell__avatar",
                    "aria-hidden": "true",
                    children: (0, a.jsx)(c.YK, { size: 20, weight: 400 }),
                  }),
                  (0, a.jsxs)("div", {
                    className: "settings-cell__text",
                    children: [
                      (0, a.jsx)("h3", {
                        className: "settings-cell__label",
                        children: j("Notifications"),
                      }),
                      (0, a.jsx)("p", {
                        className: "settings-cell__caption",
                        children: j(
                          "Enable or disable notifications of start and end of meeting",
                        ),
                      }),
                    ],
                  }),
                  (0, a.jsx)(l.r, {
                    className: "shrink-0",
                    checked: I,
                    onCheckedChange: k,
                  }),
                ],
              }),
            }),
            z &&
              (0, a.jsx)("div", {
                className: "settings-section settings-cell",
                children: (0, a.jsxs)("div", {
                  className: "settings-cell__row",
                  children: [
                    (0, a.jsx)("span", {
                      className: "settings-cell__avatar",
                      "aria-hidden": "true",
                      children: (0, a.jsx)(m, { size: 20, weight: 400 }),
                    }),
                    (0, a.jsxs)("div", {
                      className: "settings-cell__text",
                      children: [
                        (0, a.jsx)("h3", {
                          className: "settings-cell__label",
                          children: j("Hide from the Dock"),
                        }),
                        (0, a.jsx)("p", {
                          className: "settings-cell__caption",
                          children: j(
                            "Memento stays in the menu bar only. Open it from the icon at the top.",
                          ),
                        }),
                      ],
                    }),
                    (0, a.jsx)(l.r, {
                      className: "shrink-0",
                      checked: M,
                      onCheckedChange: T,
                    }),
                  ],
                }),
              }),
            (null == A ? void 0 : A.supported) !== !1 &&
              (0, a.jsx)("div", {
                className: "settings-section settings-cell",
                children: (0, a.jsxs)("div", {
                  className: "settings-cell__row",
                  children: [
                    (0, a.jsx)("span", {
                      className: "settings-cell__avatar",
                      "aria-hidden": "true",
                      children: (0, a.jsx)(g, { size: 20, weight: 400 }),
                    }),
                    (0, a.jsx)("div", {
                      className: "settings-cell__text",
                      children: (0, a.jsx)("h3", {
                        className: "settings-cell__label",
                        children: j("Automatic call recording"),
                      }),
                    }),
                    (0, a.jsx)(l.r, {
                      className: "shrink-0",
                      "aria-label": j("Automatic call recording"),
                      checked: "live" === V,
                      disabled: !t || e,
                      onCheckedChange: (e) => void O(e ? "live" : "off"),
                    }),
                  ],
                }),
              }),
            !F &&
              (0, a.jsx)("div", {
                className: "settings-section",
                children: (0, a.jsxs)("div", {
                  className: "flex items-start justify-between gap-4 sm:gap-6",
                  children: [
                    (0, a.jsxs)("div", {
                      className: "min-w-0",
                      children: [
                        (0, a.jsx)("h3", {
                          className:
                            "text-lg font-semibold text-[var(--fg1)] mb-2",
                          children: j(
                            "Open Telegram after a summary is generated",
                          ),
                        }),
                        (0, a.jsx)("p", {
                          className: "text-sm text-[var(--fg2)]",
                          children: j(
                            "Telegram opens its chat picker with the meeting title in the draft and the summary on the clipboard, ready to paste. You choose the chat and press send — the app never sends anything by itself.",
                          ),
                        }),
                      ],
                    }),
                    (0, a.jsx)(l.r, {
                      className: "shrink-0",
                      checked: Z,
                      onCheckedChange: R,
                    }),
                  ],
                }),
              }),
          ],
        });
      }
    },
    61362: function (e, s, t) {
      t.d(s, {
        _: function () {
          return d;
        },
      });
      var a = t(15791),
        i = t(52236),
        l = t(93391),
        n = i.forwardRef((e, s) =>
          (0, a.jsx)(l.WV.label, {
            ...e,
            ref: s,
            onMouseDown: (s) => {
              var t;
              s.target.closest("button, input, select, textarea") ||
                (null === (t = e.onMouseDown) || void 0 === t || t.call(e, s),
                !s.defaultPrevented && s.detail > 1 && s.preventDefault());
            },
          }),
        );
      n.displayName = "Label";
      var c = t(96660),
        o = t(95232);
      let r = (0, c.j)(
          "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70",
        ),
        d = i.forwardRef((e, s) => {
          let { className: t, ...i } = e;
          return (0, a.jsx)(n, { ref: s, className: (0, o.cn)(r(), t), ...i });
        });
      d.displayName = n.displayName;
    },
  },
]);
